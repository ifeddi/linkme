<?php

namespace App\Controller;

use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Routing\Annotation\Route;

class AuthController extends AbstractController
{
    #[Route('/api/user/register', name: 'api_user_register', methods: ['POST'])]
    public function register(
        Request $request,
        EntityManagerInterface $entityManager,
        UserPasswordHasherInterface $passwordHasher
    ): Response {
        $data = json_decode($request->getContent(), true) ?? [];

        $email = isset($data['email']) ? trim((string) $data['email']) : '';
        $plainPassword = isset($data['password']) ? (string) $data['password'] : '';
        $username = isset($data['name']) ? trim((string) $data['name']) : '';

        if ($email === '' || $plainPassword === '' || $username === '') {
            return new JsonResponse(['message' => 'Email, password and username are required'], Response::HTTP_BAD_REQUEST);
        }

        // Check if user already exists
        $existing = $entityManager->getRepository(User::class)->findOneBy(['email' => $email]);
        if ($existing) {
            return new JsonResponse(['message' => 'User already exists'], Response::HTTP_CONFLICT);
        }

        $user = new User();
        $user->setEmail($email);

        // Ensure unique username
        $existingUsername = $entityManager->getRepository(User::class)->findOneBy(['name' => $username]);
        if ($existingUsername) {
            return new JsonResponse(['message' => 'Username already exists'], Response::HTTP_CONFLICT);
        }
        $user->setName($username);
        $user->setBio('');
        $user->setRoles(['ROLE_USER']);

        $hashedPassword = $passwordHasher->hashPassword($user, $plainPassword);
        $user->setPassword($hashedPassword);

        $entityManager->persist($user);
        $entityManager->flush();

        return new JsonResponse(['message' => 'User created'], Response::HTTP_CREATED);
    }

    #[Route('/api/user/profile', name: 'api_user_profile', methods: ['GET'])]
    public function getProfile(): Response
    {
        $user = $this->getUser();
        
        if (!$user) {
            return new JsonResponse(['message' => 'User not authenticated'], Response::HTTP_UNAUTHORIZED);
        }

        return new JsonResponse([
            'id' => $user->getId(),
            'email' => $user->getEmail(),
            'name' => $user->getName(),
            'bio' => $user->getBio(),
            'profilePhoto' => $user->getProfilePhoto(),
            'postsCount' => $user->getPosts()->count(),
            'followersCount' => $user->getFollowers()->count(),
            'followingCount' => $user->getFollowing()->count()
        ]);
    }

    #[Route('/api/user/profile', name: 'api_user_update_profile', methods: ['PUT'])]
    public function updateProfile(
        Request $request,
        EntityManagerInterface $entityManager,
        UserPasswordHasherInterface $passwordHasher
    ): Response {
        $user = $this->getUser();
        
        if (!$user) {
            return new JsonResponse(['message' => 'User not authenticated'], Response::HTTP_UNAUTHORIZED);
        }

        $data = json_decode($request->getContent(), true) ?? [];

        $email = isset($data['email']) ? trim((string) $data['email']) : '';
        $name = isset($data['name']) ? trim((string) $data['name']) : '';
        $bio = isset($data['bio']) ? trim((string) $data['bio']) : '';
        $profilePhoto = isset($data['profilePhoto']) ? trim((string) $data['profilePhoto']) : null;

        if ($email === '') {
            return new JsonResponse(['message' => 'Email is required'], Response::HTTP_BAD_REQUEST);
        }

        // Vérifier si l'email est déjà utilisé par un autre utilisateur
        if ($email !== $user->getEmail()) {
            $existing = $entityManager->getRepository(User::class)->findOneBy(['email' => $email]);
            if ($existing) {
                return new JsonResponse(['message' => 'Email already exists'], Response::HTTP_CONFLICT);
            }
        }

        // Vérifier si le nom d'utilisateur est déjà utilisé par un autre utilisateur
        if ($name !== '' && $name !== $user->getName()) {
            $existing = $entityManager->getRepository(User::class)->findOneBy(['name' => $name]);
            if ($existing) {
                return new JsonResponse(['message' => 'Username already exists'], Response::HTTP_CONFLICT);
            }
        }

        // Mettre à jour les données
        $user->setEmail($email);
        $user->setName($name);
        $user->setBio($bio);
        $user->setProfilePhoto($profilePhoto);

        $entityManager->flush();

        return new JsonResponse([
            'message' => 'Profile updated successfully',
            'user' => [
                'id' => $user->getId(),
                'email' => $user->getEmail(),
                'name' => $user->getName(),
                'bio' => $user->getBio(),
                'profilePhoto' => $user->getProfilePhoto(),
                'postsCount' => $user->getPosts()->count(),
                'followersCount' => $user->getFollowers()->count(),
                'followingCount' => $user->getFollowing()->count()
            ]
        ]);
    }
}


